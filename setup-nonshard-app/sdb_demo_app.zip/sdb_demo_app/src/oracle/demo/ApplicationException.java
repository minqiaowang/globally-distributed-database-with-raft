package oracle.demo;

public class ApplicationException extends Exception
{
    public ApplicationException(String msg) {
        super(msg);
    }
}
